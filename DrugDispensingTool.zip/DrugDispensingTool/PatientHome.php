<?php
// ... Database connection and other code ...
require_once 'connection.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve the form data
    $Email = $_POST['Email'];
    $Password = $_POST['Password'];

    // Prepare and execute the SQL query to retrieve the patient's record
    $sql = "SELECT * FROM Patients WHERE Email = '$Email'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $storedPassword = $row['Password'];

        // Verify the entered password against the stored password
        if ($Password === $storedPassword) {
            // Password is correct
            // Redirect the patient to their account dashboard or other page
            header("Location: Patients.php");
            exit();
        } else {
            // Password is incorrect
            echo "Invalid password. Please try again.";
        }
    } else {
        // Patient record not found
        echo "Invalid email. Please try again.";
    }
}

// ... Close the database connection and other code ...
?>



<!DOCTYPE html>
<html>
<head>
    <title>Patient Login</title>
</head>
<body>
    <h2>Patient Login</h2>
    <form action="connection.php" method="POST">
        <label for="Email">Email:</label>
        <input type="email" id="Email" name="Email" required><br><br>

        <label for="Password">Password:</label>
        <input type="password" id="Password" name="Password" required><br><br>

        <input type="submit" value="Login">
    </form><br>
   Don't have an account? <a href = "patient_registration.php" > Click here!</a>


   

</body>
</html>
