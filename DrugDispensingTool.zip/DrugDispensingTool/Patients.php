<?php
require_once ("connection.php");
include_once("");
include("connection.php");
require("connection.php");

$first_name = "Mary";
$email = "mary@gmail.com";
$phone = "0723456789";

$sql = "INSERT INTO Patients( first_name , email , phone )
VALUES ('$first_name', '$email', '$phone' )";

if($conn->query($sql) === TRUE){
    echo "New record created successfully";
} else {
    echo "Error: ". $sql . "<br>" . $conn ->error;
}

$conn -> close();

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the submitted form data
    $ssn = $_POST["ssn"];
    $name = $_POST["name"];
    $address = $_POST["address"];
    $age = $_POST["age"];
    
    // Prepare the SQL statement
    $sql = "UPDATE patients SET Name=?, Address=?, Age=? WHERE SSN=?";
    $stmt = $conn->prepare($sql);
    
    // Bind the parameters and execute the statement
    $stmt->bind_param("ssis", $name, $address, $age, $ssn);
    $stmt->execute();
    
    // Check for errors during the update operation
    if ($stmt->errno) {
        echo "Error: " . $stmt->error;
    } else {
        // Check if the update was successful
        if ($stmt->affected_rows > 0) {
            echo "Patients information updated successfully.";
        } else {
            echo "Failed to update patients information.";
        }
    }
    
    // Close the statement
    $stmt->close();
}
// Close the connection
$conn->close();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the submitted form data
    $ssn = $_POST["ssn"];
    $name = $_POST["name"];
    $address = $_POST["address"];
    $age = $_POST["age"];
    
    // Prepare the SQL statement
    $sql = "UPDATE patients SET Name=?, Address=?, Age=? WHERE SSN=?";
    $stmt = $conn->prepare($sql);
    
    // Bind the parameters and execute the statement
    $stmt->bind_param("ssis", $name, $address, $age, $ssn);
    $stmt->execute();
}

echo($sql);

print_r($_POST);
?>