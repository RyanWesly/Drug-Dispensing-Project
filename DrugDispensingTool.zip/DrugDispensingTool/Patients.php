<?php

echo "Welcome Patient!";

?>