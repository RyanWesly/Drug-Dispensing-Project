<!DOCTYPE html>
<html>
<head>
    <title>Home Page</title>
</head>
<body>
    <h1>WELCOME TO KUGZY DRUG DISPENSING TOOL</h1>
    <h2>PLEASE SELECT YOUR ROLE</h2>
    
    <form method="post" action="index.php">
        <input type="submit" name="patient" value="Patient"> </br></br>
        <input type="submit" name="doctor" value="Doctor"></br></br>
        <input type="submit" name="pharmacy" value="Pharmacy"></br></br>
    </form>

    <?php
    if (isset($_POST['patient'])) {
        header("Location: PatientHome.php");
        exit();
    } elseif (isset($_POST['doctor'])) {
        header("Location: DoctorHome.php");
        exit();
    } elseif (isset($_POST['pharmacy'])) {
        header("Location: PharmacyHome.php");
        exit();
    }
    ?>
</body>
</html>
