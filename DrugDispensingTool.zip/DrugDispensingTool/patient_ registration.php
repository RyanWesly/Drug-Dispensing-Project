<!DOCTYPE html>
<html>
<head>
    <title>Patient Registration</title>
</head>
<body>
    <h2>Patient Registration</h2>
    <form action="connection.php" method="POST">
        <label for="FullName">Full Name:</label>
        <input type="text" id="FullName" name="FullName" required><br><br>

        <label for="PatientNo">Patient Number:</label>
        <input type="text" id="PatientNo" name="PatientNo" required><br><br>

        <label for="PatientSSN">Patient SSN:</label>
        <input type="text" id="PatientSSN" name="PatientSSN" required><br><br>

        <label for="Contacts">Contacts:</label>
        <input type="text" id="Contacts" name="Contacts" required><br><br>

        <label for="Email">Email:</label>
        <input type="email" id="Email" name="Email" required><br><br>

        <label for="Password">Password:</label>
        <input type="text" id="Password" name="Password" required><br><br>

        <label for="DateOfBirth">Date of Birth:</label>
        <input type="date" id="DateOfBirth" name="DateOfBirth" required><br><br>

        <label for="EmergencyContact">Emergency Contact:</label>
        <input type="text" id="EmergencyContact" name="EmergencyContact" required><br><br>

        <label for="Address">Address:</label>
        <textarea id="Address" name="Address" required></textarea><br><br>

        <label for="PreExistingConditions">Pre-existing Conditions:</label>
        <input type="text" id="PreExistingConditions" name="PreExistingConditions"><br><br>

        <label for="DoctorName">Doctor Name:</label>
        <input type="text" id="DoctorName" name="DoctorName" required><br><br>

        <label for="DoctorSSN">Doctor SSN:</label>
        <input type="text" id="DoctorSSN" name="DoctorSSN" required><br><br>

        <input type="submit" value="Register">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Database connection details
        $servername = "localhost";
$username = "root";
$password = "";
$dbname = "DrugDispensingTool";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

        // Check the connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Retrieve the form data
        $FullName = $_POST['FullName'];
        $PatientNo = $_POST['PatientNo'];
        $PatientSSN = $_POST['PatientSSN'];
        $Contacts = $_POST['Contacts'];
        $Email = $_POST['Email'];
        $Password = $_POST['Password'];
        $DateOfBirth = $_POST['DateOfBirth'];
        $EmergencyContact = $_POST['EmergencyContact'];
        $Address = $_POST['Address'];
        $PreExistingConditions = $_POST['PreExistingConditions'];
        $DoctorName = $_POST['DoctorName'];
        $DoctorSSN = $_POST['DoctorSSN'];

        $hashedPassword = password_hash($Password, PASSWORD_DEFAULT);

        // Prepare and execute the SQL query to insert the data into the database
        $sql = "INSERT INTO Patients (FullName, PatientNo, PatientSSN, Contacts, Email, Password, DateOfBirth, EmergencyContact, Address, PreExistingConditions, DoctorName, DoctorSSN)
                VALUES ('$FullName', '$PatientNo', '$PatientSSN', '$Contacts', '$Email', '$Password', '$DateOfBirth', '$EmergencyContact', '$Address', '$PreExistingConditions', '$DoctorName', '$DoctorSSN')";

        if ($conn->query($sql) === TRUE) {
            echo "Patient registration successful.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        // Close the database connection
        $conn->close();
    }
    ?>
</body>
</html>
